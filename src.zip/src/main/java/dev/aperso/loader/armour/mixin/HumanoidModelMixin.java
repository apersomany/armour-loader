package dev.aperso.loader.armour.mixin;

import dev.aperso.loader.armour.Armour;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HumanoidModel.class)
public class HumanoidModelMixin {
    @Shadow @Final public ModelPart head;
    @Shadow @Final public ModelPart body;
    @Shadow @Final public ModelPart leftArm;
    @Shadow @Final public ModelPart rightArm;
    @Shadow @Final public ModelPart leftLeg;
    @Shadow @Final public ModelPart rightLeg;

    @Inject(method = "prepareMobModel(Lnet/minecraft/world/entity/LivingEntity;FFF)V", at = @At("HEAD"))
    private void onPrepareMobModel(LivingEntity livingEntity, float f, float g, float h, CallbackInfo ci) {
        Armour head = Armour.of(livingEntity.getItemBySlot(EquipmentSlot.HEAD));
        if (head != null) {
            if (head.props().get("overrideModelHead").equals(true)) {
                this.head.visible = false;
            }
        }
        Armour chest = Armour.of(livingEntity.getItemBySlot(EquipmentSlot.CHEST));
        if (chest != null) {
            if (chest.props().get("overrideModelChest").equals(true)) {
                body.visible = false;
            }
            if (chest.props().get("overrideModelArmLeft").equals(true)) {
                leftArm.visible = false;
            }
            if (chest.props().get("overrideModelArmRight").equals(true)) {
                rightArm.visible = false;
            }
        }
//        Armour legs = Armour.of(livingEntity.getItemBySlot(EquipmentSlot.LEGS));
//        if (legs != null) {
//            if (legs.props().get("overrideModelLegLeft").equals(true)) {
//                leftLeg.visible = false;
//            }
//            if (legs.props().get("overrideModelLegRight").equals(true)) {
//                rightLeg.visible = false;
//            }
//        }
//        Armour feet = Armour.of(livingEntity.getItemBySlot(EquipmentSlot.FEET));
//        if (feet != null) {
//            if (legs.props().get("overrideModelLegLeft").equals(true)) {
//                leftLeg.visible = false;
//            }
//            if (legs.props().get("overrideModelLegRight").equals(true)) {
//                rightLeg.visible = false;
//            }
//        }
    }
}
